import voteStore3

if __name__ == '__main__':
    voteStore3.app.run(debug=True, port=5300)