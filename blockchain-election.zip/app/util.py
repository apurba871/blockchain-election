from app import db
import app.cast_vote_util as cast_vote_util
from app.models import Voter_List, Election, CandidateList
from flask import redirect, url_for, render_template
from flask_login import current_user

# Returns True if voter_id is debarred from election_id, False otherwise
def checkDebarStatus(election_id, voter_id):
    voter_tries = Voter_List.getVoterTries(election_id, voter_id)
    election_max_attempt = Election.getElectionRecord(election_id).max_attempt
    return voter_tries == election_max_attempt

def checkIfAlreadyVoted(election_id, voter_id):
    from app.models import Casted_Vote
    # vote_exists_in_ballot = Casted_Vote.query.filter_by(election_id=election_id, id=voter_id).first()
    # return True if vote_exists_in_ballot else False
    return cast_vote_util.checkIfPresent(voter_id=int(voter_id), election_id=election_id)


def checkOTPAndRedirect(user_otp, election_id):
    otp = Voter_List.getVoterToken(election_id, current_user.id)
    tries = Voter_List.getVoterTries(election_id, current_user.id)
    candidates = CandidateList.getAllCandidates(election_id)
    if user_otp == otp:
        # if valid then take him to the voting page
        return render_template("cast_your_vote.html", candidates=candidates, election_id=election_id)
    else:
        # increase tries count by 1 and ask him to enter the correct token again until tries reaches max_attempts
        curr_election = Election.query.where(Election.election_id==election_id).first()
        Voter_List.incrementVoterTries(election_id, current_user.id)
        db.session.commit()
        if tries < curr_election.max_attempt - 1:
            return redirect(url_for("view_election", id=curr_election.election_id))
        else:
            # if max_attempt reached then debar him from the voting process
            return render_template("debar_from_voting.html", voter_id=current_user.id)