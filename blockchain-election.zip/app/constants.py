provider_address = "HTTP://127.0.0.1:7545"
chain_id = 1337
my_address = "0x5cB4BA24fb4Ca0f7D2A88942c9bc01D9c5a3C128"
private_key = "d9c74a6a0942fdea70100b77fb73c8488e15c396b4489d5e1c6a7e8a75773b18"
contractAddress = '0xa08E59419A2998137aa8b15b64a94aE27E582048'