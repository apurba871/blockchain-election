import voteStore2

if __name__ == '__main__':
    voteStore2.app.run(debug=True, port=5200)