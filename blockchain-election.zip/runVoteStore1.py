import voteStore1

if __name__ == '__main__':
    voteStore1.app.run(debug=True, port=5100)